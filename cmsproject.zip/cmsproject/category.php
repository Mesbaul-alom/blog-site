<?php include 'includes/header.php'; ?>
<!-- BreadCrumb Start -->
<div class="breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-inner">
                    <h2>Blog Grid</h2>
                    <p>
                        <a href="index.php">Home</a>
                        <span>Blog Grid</span>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- BreadCrumb Ends -->
</header>
<!-- Header Area Ends -->
<!-- Blog Grid Start -->
<div class="blog-grid section-padding">
<div class="container">
    <div class="row">
        <!-- Blog Content Start -->
        <div class="col-lg-8">
            <?php  

                if (isset($_GET['id'])) {
                    $the_category_page_id = $_GET['id'];
                    $sql = "SELECT * FROM posts WHERE post_category = '$the_category_page_id'";

                    // echo $sql;

                    $all_cat_post = mysqli_query($connect, $sql);
                    $total_post = mysqli_num_rows($all_cat_post);
                    if ($total_post == 0 || $total_post < 0) {
                        echo "No post found in this category";
                    }
                    else{

 
                        $sql = "SELECT * FROM posts WHERE post_category = '$the_category_page_id'";
                        $all_blogs = mysqli_query($connect, $sql);

                        while($row = mysqli_fetch_assoc($all_blogs)){
                            $post_id            = $row['post_id'];
                            $post_title         = $row['post_title'];
                            $post_description   = $row['post_description'];
                            $post_author        = $row['post_author'];
                            $post_thumb         = $row['post_thumb'];
                            $post_category      = $row['post_category'];
                            $post_tags          = $row['post_tags'];
                            $post_date          = $row['post_date'];
                    ?>

                    <div class="row">
                        <div class="col-md-3">
                            <div class="cat mb-2">
                                <ul class="catitem d-flex">
                                    <?php  
                                        $sql = "SELECT * FROM categories WHERE cat_id = '$post_category'";
                                        $cat_items = mysqli_query($connect, $sql);

                                        while ($row = mysqli_fetch_assoc($cat_items)) {
                                            $cat_id = $row['cat_id'];
                                            $cat_name = $row['cat_name'];
                                    ?>
                                    <li class="mr-1"><a class="text-info" href="#"><?php echo $cat_name; ?></a></li>
                                    <?php
                                        }
                                    ?> 
                                </ul>
                            </div>
                            <div class="auth mb-2">
                                <a class="text-primary" href="#"><?php echo $post_author; ?></a>
                            </div>
                            <div class="tag mb-2">
                                <ul class="tagitem d-flex">
                                    <li class="mr-1"><a class="text-dark" href="#">Education</a></li>
                                    <li><a class="text-dark" href="#">Health</a></li>
                                </ul>
                            </div>
                            <div class="date mb-2">
                                <p>20 - Jan - 2020</p>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="blog-grid-item wow fadeInUp delay-2">
                                <div class="blog-img">
                                    <div class="blog-date">
                                        <p>25 April, 2020</p>
                                    </div>
                                    <a href="single.php?id=<?php echo $post_id; ?>">
                                        <img src="admin/img/post-thumbnail/<?php echo $post_thumb; ?>" alt="Blog" class="img-fluid">
                                    </a>
                                    <div class="blog-author text-uppercase">
                                        <p>Admin</p>
                                    </div>
                                </div>
                                <div class="blog-info">
                                    <a href="single.php?id=<?php echo $post_id; ?>">
                                        <h3><?php echo $post_title; ?></h3>
                                    </a>
                                    <p>
                                        <?php echo substr($post_description, 0,100); ?>
                                    </p>
                                    <a class="blog-btn" href="single.php?id=<?php echo $post_id; ?>">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>

            <?php
                }}}
            ?>
            
        </div>
        <!-- Blog Content End -->
        <!-- Sidebar Start -->
        <div class="col-lg-4">
            <?php include 'includes/sidebar.php'; ?>
        </div>
        <!-- Sidebar End -->
        
    </div>
    <div class="blog-pagination">
        <nav aria-label="Page navigation example">
            <ul class="pagination justify-content-center">
                <li class="page-item disabled">
                    <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
                </li>
                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
                <li class="page-item">
                    <a class="page-link" href="#">Next</a>
                </li>
            </ul>
        </nav>
    </div>
</div>
</div>
<!-- Blog Grid Ends -->

<?php include 'includes/footer.php'; ?>