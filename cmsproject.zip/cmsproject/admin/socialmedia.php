<?php include 'includes/header.php'; ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">Social Media URL's Update</h1>

        <div class="row">
        	<div class="col-md-12">
        		<div class="card shadow mb-4">
	                <div class="card-header py-3">
	                    <h6 class="m-0 font-weight-bold text-primary">Upload Website Logo</h6>
	                </div>
	                <div class="card-body">
	                   <form action="" method="POST" class="mb-2">
	                   		 <div class="row">
		                    	<div class="col-md-2">
		                    		<label for="Facebook Url" class="col-form-label">Facebook</label>
		                    	</div>
		                    	<div class="col-md-8">
				            	<?php  
				            		$sql = "SELECT * FROM socialmedia WHERE s_id = 1";
				            		$read_url = mysqli_query($connect, $sql);
				            		while($row = mysqli_fetch_assoc($read_url)){
				            			$s_link = $row['s_link'];
				            		}
				            		if (empty($s_link)) {
				            		?>
				            			<input name="url_link" type="text" class="form-control" placeholder="facebook url">
				            		<?php
				            		}
				            		else{
				            		?>
				            			<input name="url_link" type="text" class="form-control" value="<?php echo $s_link; ?>">
				            		<?php
				            		}
				            	?>
		                    		 
		                    	</div>
		                    	<div class="col-md-2">
		                    		<input type="submit" name="facebook-save" value="save" class="btn btn-primary">
		                    	</div>
		                    </div>
	                   </form>
	                   <?php 
	                   		if (isset($_POST['facebook-save'])) {
	                   			$url_link = $_POST['url_link'];
	                   			$sql = "UPDATE socialmedia SET s_link='$url_link' WHERE s_id = 1";

	                   			$updateLink = mysqli_query($connect, $sql);

	                   			if (!$updateLink) { die("Operation Faield"); }
	                   			else{
	                   				header("Location: socialmedia.php");
	                   			}
	                   		}
	                   ?>
	                   <!-- Facebook end -->

	                   <form action="" method="POST" class="mb-2">
	                   		 <div class="row">
		                    	<div class="col-md-2">
		                    		<label for="Facebook Url" class="col-form-label">YouTube</label>
		                    	</div>
		                    	<div class="col-md-8">
		                    		<?php  
				            		$sql = "SELECT * FROM socialmedia WHERE s_id = 2";
				            		$read_url = mysqli_query($connect, $sql);
				            		while($row = mysqli_fetch_assoc($read_url)){
				            			$s_link = $row['s_link'];
				            		}
				            		if (empty($s_link)) {
				            		?>
				            			<input name="url_link" type="text" class="form-control" placeholder="youtube url">
				            		<?php
				            		}
				            		else{
				            		?>
				            			<input name="url_link" type="text" class="form-control" value="<?php echo $s_link; ?>">
				            		<?php
				            		}
				            	?>
		                    	</div>
		                    	<div class="col-md-2">
		                    		<input type="submit" name="youtube-save" value="save" class="btn btn-primary">
		                    	</div>
		                    </div>
	                   </form>
	                    <?php 
	                   		if (isset($_POST['youtube-save'])) {
	                   			$url_link = $_POST['url_link'];
	                   			$sql = "UPDATE socialmedia SET s_link='$url_link' WHERE s_id = 2";

	                   			$updateLink = mysqli_query($connect, $sql);

	                   			if (!$updateLink) { die("Operation Faield"); }
	                   			else{
	                   				header("Location: socialmedia.php");
	                   			}
	                   		}
	                   ?>
	                   <!-- Youtube end -->

	                   <form action="" method="POST" class="mb-2">
	                   		 <div class="row">
		                    	<div class="col-md-2">
		                    		<label for="Linkedin Url" class="col-form-label">Linkedin</label>
		                    	</div>
		                    	<div class="col-md-8">
		                    		 <input name="url_link" type="text" class="form-control" placeholder="linkedin url">
		                    	</div>
		                    	<div class="col-md-2">
		                    		<input type="submit" name="linkedin-save" value="save" class="btn btn-primary">
		                    	</div>
		                    </div>
	                   </form>
	                   <!-- Linkedin end -->


	                   <form action="" method="POST" class="mb-2">
	                   		 <div class="row">
		                    	<div class="col-md-2">
		                    		<label for="Twitter Url" class="col-form-label">Twitter</label>
		                    	</div>
		                    	<div class="col-md-8">
		                    		 <input name="url_link" type="text" class="form-control" placeholder="twitter url">
		                    	</div>
		                    	<div class="col-md-2">
		                    		<input type="submit" name="twitter-save" value="save" class="btn btn-primary">
		                    	</div>
		                    </div>
	                   </form>
	                   <!-- Twitter end -->


	                   <form action="" method="POST">
	                   		 <div class="row">
		                    	<div class="col-md-2">
		                    		<label for="Instagram Url" class="col-form-label">Instagram</label>
		                    	</div>
		                    	<div class="col-md-8">
		                    		 <input name="url_link" type="text" class="form-control" placeholder="instagram url">
		                    	</div>
		                    	<div class="col-md-2">
		                    		<input type="submit" name="instagram-save" value="save" class="btn btn-primary">
		                    	</div>
		                    </div>
	                   </form>
	                   <!-- Twitter end -->
	                </div>
	            </div>
        	</div>
        </div>
    </div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
<?php include 'includes/footer.php'; ?>

           