<?php include 'includes/header.php'; ?>
<?php 
    $message = ""; 
    if (isset($_POST['addCategory'])){
        $cat_name = $_POST['category'];
        if(empty($cat_name)){
            $message = '<div class="alert alert-warning">Category Name Cannot Be Empty</div>';
        }
        else{
            $query = "INSERT INTO categories (cat_name) VALUES ('$cat_name')";
            $addCategory = mysqli_query($connect, $query);

            if (!$addCategory) {
                die("Query Failed" . mysqli_error($connect));
            }
            else{
                header('Location: all-category.php');
            }
        }
    }
?>


  <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">View All Categories</h1>

        <div class="row">
            <div class="col-md-5">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Add New Category</h6>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="form-group">
                                <label for="category">Add Category Name</label>
                                <input name="category" type="text" class="form-control" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <input name="addCategory" type="submit" class="btn btn-primary" value="Add Category">
                            </div>
                        </form>

                        <?php  
                            echo $message;
                        ?>
                    </div>
                </div>

                <?php  
                    if (isset($_GET['update'])) {
                    $cat_id = $_GET['update'];

                    $query ="SELECT * FROM categories WHERE cat_id = $cat_id";
                    $select_category_id = mysqli_query($connect, $query);
                    while ($row = mysqli_fetch_assoc($select_category_id)) {
                        $cat_id = $row['cat_id'];
                        $cat_name = $row['cat_name'];
                ?>

                <?php  
                    if (isset($_POST['editCategory'])) {
                        $cat_name = $_POST['category'];
                        $query = "UPDATE categories SET cat_name = '$cat_name' WHERE cat_id = $cat_id";
                        $update_category = mysqli_query($connect, $query); 
                        if (!$update_category) {
                            die("Query Failed" . mysqli_error($connect));
                        }
                        else{
                            header('Location: all-category.php');
                        }
                    }
                ?>
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Edit Category</h6>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="form-group">
                                <label for="category">Edit Category Name</label>
                                <input name="category" type="text" class="form-control" autocomplete="off" value="<?php if(isset($cat_id)){ echo $cat_name; } ?>">
                            </div>
                            <div class="form-group">
                                <input name="editCategory" type="submit" class="btn btn-primary" value="Update Category">
                            </div>
                        </form>
                    </div>
                </div>
            <?php } } ?>
            </div>
            <!-- Add Category End -->
            <div class="col-md-7">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">View All Category</h6>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                          <thead class="thead-dark ">
                            <tr>
                              <th scope="col">ID</th>
                              <th scope="col">Category Name</th>
                              <th scope="col">Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php 
                                $query = "SELECT * FROM categories";
                                $select_categories = mysqli_query($connect, $query);
                                while($row = mysqli_fetch_assoc($select_categories)){
                                    $cat_id = $row['cat_id'];
                                    $cat_name = $row['cat_name'];

                            ?>
                            <tr>
                              <th scope="row"> <?php echo $cat_id; ?> </th>
                              <td><?php echo $cat_name; ?></td>
                              <td>
                                  <div class="btn-group">
                                      <a href="all-category.php?update=<?php echo $cat_id; ?>" class="btn btn-primary btn-sm">Edit</a>

                                      <a href="all-category.php?delete=<?php echo $cat_id; ?>" class="btn btn-danger btn-sm">Delete</a>
                                  </div>
                              </td>
                            </tr>
                            <?php } ?>
                          </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<?php  
    if (isset($_GET['delete'])) {
        $the_cat_id = $_GET['delete'];

        $query = "DELETE FROM categories WHERE cat_id = $the_cat_id";
        $delete_category = mysqli_query($connect, $query);
        if (!$delete_category) {
            die("Query Faild" . mysqli_error($connect));
        }
        else{
            header('Location: all-category.php');
        }
    }
?>
<!-- End of Main Content -->
<?php include 'includes/footer.php';?>