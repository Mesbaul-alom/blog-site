<?php include 'includes/header.php'; ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">All Blog Post:</h1>
        <!-- Basic Card Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">All Post</h6>
                <a href="add-post.php">Add Post</a>
            </div>
            <div class="card-body">
                <table class="table">
				  <thead class="thead-dark">
				    <tr>
				      <th scope="col">Sl.</th>
				      <th scope="col">Title</th>
				      <th scope="col">Author</th>
				      <th scope="col">Category</th>
				      <th scope="col">Date</th>
				      <th scope="col">Action</th>
				    </tr>
				  </thead>
				  <tbody>
				  	<?php  

				  		$query = "SELECT * FROM posts";
				  		$select_all_post = mysqli_query($connect, $query);

				  		$sl = 0;

				  		while ($row = mysqli_fetch_assoc($select_all_post)) {
				  			$post_id 			= $row['post_id'];
				  			$post_title 		= $row['post_title'];
				  			$post_description 	= $row['post_description'];
				  			$post_author 		= $row['post_author'];
				  			$post_thumb 		= $row['post_thumb'];
				  			$post_category 		= $row['post_category'];
				  			$post_tags 			= $row['post_tags'];
				  			$post_date 			= $row['post_date'];
				  			$sl++;

				  	?>

				  		<tr>
					      <td><?php echo $sl; ?></td>
					      <td><?php echo $post_title; ?></td>
					      <td><?php echo $post_author; ?></td>
					      <td>
					      	<?php  
					      		// echo $post_category;
					      		$query = "SELECT * FROM categories WHERE cat_id ='$post_category'";
                                $the_cat = mysqli_query($connect, $query);
                                while ($row = mysqli_fetch_assoc($the_cat)) {
                                    $cat_id   = $row['cat_id'];
                                    $cat_name    = $row['cat_name'];
                                }
                                echo $cat_name;
					      	?>		
					      </td>
					      <td><?php echo $post_date; ?></td>
					      <td>
							<div class="btn-group">
								<a class="btn btn-primary btn-sm" href="update-post.php?update=<?php echo $post_id; ?>">Edit</a>
								<a class="btn btn-danger btn-sm" href="all-post.php?delete=<?php echo $post_id; ?>">Delete</a>
							</div>
						</td>
					    </tr>


				  	<?php
				  		}
				  	?>
				  </tbody>
				</table>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->


    <?php  
    	if (isset($_GET['delete'])) {
    		$delete_post = $_GET['delete'];
    		$query = "DELETE FROM posts WHERE post_id = '$delete_post'";

    		$delete_post  = mysqli_query($connect, $query);
    		if (!$delete_post) {
    			die("Query Faield" . mysqli_error($connect));
    		}
    		else{
    			header("Location: all-post.php");
    		}
    	}
    ?>

</div>
<!-- End of Main Content -->
<?php include 'includes/footer.php'; ?>
