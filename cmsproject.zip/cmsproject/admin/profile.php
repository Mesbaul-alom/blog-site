<?php include 'includes/header.php'; ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">Manage Your Profile</h1>
    	<!-- /.container-fluid -->
    	<div class="row">
    		<div class="col-md-4">
    			<div class="card shadow mb-4">
					<div class="card-header py-3">
						<h6 class="m-0 font-weight-bold text-primary">User Information</h6>
					</div>
					<div class="card-body">
					<?php 
						$user_id = $_SESSION['id'];
						$query = "SELECT * FROM users WHERE id='$user_id'";
						$the_user = mysqli_query($connect, $query);
						while ( $row = mysqli_fetch_assoc($the_user)) {
							$id 		= $row['id'];
							$name 		= $row['name'];
							$username 	= $row['username'];
							$password 	= $row['password'];
							$email 		= $row['email'];
							$phone 		= $row['phone'];
							$address 	= $row['address'];
							$avater 	= $row['avater'];
							$role 		= $row['role'];
							$join_date 	= $row['join_date'];
						}
					?>
					
					<?php 

                        if (!empty($avater)) {
                    ?>
                    <img class="img-fluid"
                    src="img/user-avater/<?php echo $avater; ?>">
                    <?php 
                        }
                        else{
                        ?>
                        <img class="img-fluid" src="img/user-avater/default.jpg" alt="">
                        <?php
                        }

                    ?>
					<table class="table table-striped table-dark">
					  <tbody>
					    <tr>
					      <td>Fullname: </td>
					      <td><?php echo $name; ?></td>
					    </tr>
					    <tr>
					      <td>Username: </td>
					      <td><?php echo $username; ?></td>
					    </tr>
					    <tr>
					      <td>Email Address: </td>
					      <td><?php echo $email; ?></td>
					    </tr>
					    <tr>
					      <td>Phone Number: </td>
					      <td><?php echo $phone; ?></td>
					    </tr>
					    <tr>
					      <td>Address: </td>
					      <td><?php echo $address; ?></td>
					    </tr>
					    <tr>
					      <td>User Role: </td>
					      <td>
					      	<?php  
								if ($role==0) {
									echo '<p>Administrator</p>';
								}
								elseif ($role == 1){
									echo '<p>Editor</p>';
								}
								else{
									echo '<p>Suspended</p>';
								}
							?>

					      </td>
					    </tr>
					    <tr>
					      <td>Join Date: </td>
					      <td><?php echo $join_date; ?></td>
					    </tr>
					  </tbody>
					</table>
					</div>
				</div>
    		</div>
    		<div class="col-md-8">
    			<div class="card shadow mb-4">
					<div class="card-header py-3">
						<h6 class="m-0 font-weight-bold text-primary">User Update</h6>
					</div>
					<div class="card-body">
					<?php 
						$user_id = $_SESSION['id'];
						$query = "SELECT * FROM users WHERE id='$user_id'";
						$the_user = mysqli_query($connect, $query);
						while ( $row = mysqli_fetch_assoc($the_user)) {
							$the_id 	= $row['id'];
							$name 		= $row['name'];
							$username 	= $row['username'];
							$password 	= $row['password'];
							$phone 		= $row['phone'];
							$address 	= $row['address'];
							$avater 	= $row['avater'];
					?>
						<form action="" method="POST" enctype="multipart/form-data">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<input name="name" type="text" class="form-control" required="" placeholder="Full Name" autocomplete="off" value="<?php echo $name; ?>">
								</div>
								<div class="form-group">
									<input name="username" class="form-control" required="" placeholder="User Name" autocomplete="off" value="<?php echo $username; ?>" readonly>
								</div>
								<div class="form-group">
									<input name="email" class="form-control" required="" placeholder="Email Address" autocomplete="off" value="<?php echo $email; ?>" readonly>
								</div>	
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<input name="phone" type="text" class="form-control" required="" placeholder="Phone Number" autocomplete="off" value="<?php echo $phone; ?>">
								</div>
								<div class="form-group">
									<input name="address" type="text" class="form-control" required="" placeholder="Address" autocomplete="off" value="<?php echo $address; ?>">
								</div>
								<div class="form-group">
									<label for="avater">User Avater</label>
									<br>

									<?php  
									if (!empty($avater)) {
									?>
										<img src="img/user-avater/<?php echo $avater; ?>" height="40px">
									<?php
									}

									?>
									<br>
									<input name="avater" type="file" class="form-control-file">
								</div>
								<div class="form-group">
									<input type="hidden" name="user_id" value="<?php 
									 echo $the_id; ?>">
									<input name="submit" type="submit" class="btn btn-primary" value="Save Change">
								</div>
							</div>
						</div>
					</form>
					<?php } ?>
					</div>
				</div>
    		</div>
    	</div>
    </div>

    <?php  
    	if (isset($_POST['submit'])) {
    		$update_user 	= $_POST['user_id'];
    		$name 			= $_POST['name'];
    		$phone 			= $_POST['phone'];
    		$address 		= $_POST['address'];

    		$avater 	= $_FILES['avater'];
			$avaterName = $_FILES['avater']['name'];
			$avaterSize = $_FILES['avater']['size'];
			$avaterType = $_FILES['avater']['type'];
			$avaterTmp 	= $_FILES['avater']['tmp_name'];

			$avaterAllowedExtension = array('jpg', 'jpeg', 'png');

			if (!empty($avaterName)) {
			$avater = rand(0,200000). '_' . $avaterName;
			move_uploaded_file($avaterTmp, 'img\user-avater\\' . $avater);

			$sec_query = "SELECT * FROM users WHERE id='$update_user'";
			$select_user = mysqli_query($connect, $sec_query);

			while($row = mysqli_fetch_assoc($select_user)){
				$exixting_avater = $row['avater'];
			}
			unlink("img\user-avater/".$exixting_avater);

			$query = "UPDATE users SET name='$name', phone='$phone', address='$address', avater='$avater', WHERE id='$update_user'";

			$update_user = mysqli_query($connect, $query);
			if (!$update_user) {
				die("Query Falid" . mysqli_error($connect));
			}
			else{
				header("Location: profile.php");
			}
		}
		else{
			$query = "UPDATE users SET name='$name', phone='$phone', address='$address' WHERE id='$update_user'";

			$update_user = mysqli_query($connect, $query);
			if (!$update_user) {
				die("Query Falid" . mysqli_error($connect));
			}
			else{
				header("Location: profile.php");
			}
		}
    	}

    ?>
	
	</div>
	<!-- End of Main Content -->
<?php include 'includes/footer.php'; ?>

           