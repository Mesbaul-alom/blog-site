<?php include 'includes/header.php'; ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">Website Settings</h1>

        <div class="row">
        	<div class="col-md-12">
        		<div class="card shadow mb-4">
	                <div class="card-header py-3">
	                    <h6 class="m-0 font-weight-bold text-primary">Upload Website Logo</h6>
	                </div>
	                <div class="card-body">
	                    <form action="" method="POST" enctype="multipart/form-data">
	                    	<div class="form-group">
	                    		<label for="logo">Select Logo</label>
		                    	<input name="logo" type="file" class="form-control-file">
	                    	</div>
	                    	<div class="form-group">
	                    		<label for="favicon">Select Favicon</label>
		                    	<input name="favicon" type="file" class="form-control-file">
	                    	</div>
	                    	<div class="form-group">
		                    	<input name="addSetting" type="submit" class="btn btn-primary" value="Save">
	                    	</div>
	                    </form>
	                </div>
	            </div>
        	</div>
        </div>

        <?php  
        	if (isset($_POST['addSetting'])) {
        		$logo 		= $_FILES['logo'];
        		$logoName 	= $_FILES['logo']['name'];
        		$logoTmp 	= $_FILES['logo']['tmp_name'];

        		$favicon 		= $_FILES['favicon'];
        		$faviconName 	= $_FILES['favicon']['name'];
        		$faviconTmp 	= $_FILES['favicon']['tmp_name'];

        		$logoFile 		= rand(0,200000) . '_' . $logoName;
        		$faviconFile 	= rand(0,200000) . '_' . $faviconName;

        		move_uploaded_file($logoTmp, 'img\\' . $logoFile);
        		move_uploaded_file($faviconTmp, 'img\\' . $faviconFile);

        		$sql = "UPDATE settings SET logo='$logoFile', favicon='$faviconFile' WHERE set_id = 1";

        		$add_media = mysqli_query($connect, $sql);

        		if (!$add_media) {
        			die("Operation Faild");
        		}
        		else{
        			header("Location: website-setting.php");
        		}


        	}
        ?>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
<?php include 'includes/footer.php'; ?>