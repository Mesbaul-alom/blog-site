<?php include 'includes/header.php'; ?>


    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">Add Post:</h1>
        <!-- Basic Card Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Add New Post</h6>
            </div>
            <div class="card-body">

                <?php  

                    if (isset($_GET['update'])) {
                        $the_post_id = $_GET['update'];
                        $query = "SELECT * FROM posts WHERE post_id = '$the_post_id'";

                        $post_content = mysqli_query($connect, $query);

                        while ($row = mysqli_fetch_assoc($post_content)) {
                            $post_id            = $row['post_id'];
                            $post_title         = $row['post_title'];
                            $post_description   = $row['post_description'];
                            $post_author        = $row['post_author'];
                            $post_thumb         = $row['post_thumb'];
                            $post_category      = $row['post_category'];
                            $post_tags          = $row['post_tags'];
                            $post_date          = $row['post_date'];

                            ?>

                                <form action="" method="POST" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label>Title</label>
                                        <input name="post_title" type="text" class="form-control" autocomplete="off" required="" value="<?php echo $post_title; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea name="post_description" type="text" class="form-control"><?php echo $post_description; ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label>Author</label>
                                        <input name="post_author" type="text" class="form-control" autocomplete="off" required="" value="<?php echo $post_author; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Post Thumbnail</label> <br>
                                        <img src="img/post-thumbnail/<?php echo $post_thumb; ?>" alt="" height="150" width="200">
                                        <input name="image" type="file" class="form-control-file">
                                    </div>
            <div class="form-group">
                <label>Category</label>
                <select name="post_category" class="form-control">
                    <option>Please Select The Post Category</option>
                    <?php  
                        $query = "SELECT * FROM categories";
                        $the_cat = mysqli_query($connect, $query);
                        while ($row = mysqli_fetch_assoc($the_cat)) {
                            $cat_id     = $row['cat_id'];
                            $cat_name   = $row['cat_name'];

                        ?>
                        <option value="<?php echo $cat_id; ?>" <?php if($post_category == $cat_id ){ echo 'selected'; } ?>><?php echo $cat_name; ?></option>
                        <?php
                        }

                    ?>
                </select>
            </div>
                                    <div class="form-group">
                                        <label>Tags</label>
                                        <input name="post_tags" type="text" class="form-control" autocomplete="off" required="" value="<?php echo $post_tags; ?>">
                                    </div>

                                    <div class="form-group">
                                        <input name="edit-post" type="submit" class="btn btn-primary" value="Edit Post">
                                    </div>
                                </form>



                            <?php
                        }
                    }
                ?>

                <?php  
                    if (isset($_POST['edit-post'])) {
                        $post_title         = $_POST['post_title'];
                        $post_description   = $_POST['post_description'];
                        $post_author        = $_POST['post_author'];

                        $image              = $_FILES["image"]['name'];
                        $post_image_temp    = $_FILES['image']['tmp_name'];

                        /*$image     = $_FILES['image'];
                                    $imageName = $_FILES['image']['name'];
                                    $imageSize = $_FILES['image']['size'];
                                    $avaterType = $_FILES['image']['type'];
                                    $post_image_temp  = $_FILES['image']['post_image_temp'];

                                    $imageAllowedExtension = array('jpg', 'jpeg', 'png');
                                    $imageExtension = strtolower(end(explode('.', $imageName)));*/

                        $post_category      = $_POST['post_category'];
                        $post_tag           = $_POST['post_tag'];

                       /* $formError = array();
                        if (empty($formError)) {
                                        if (!empty($imageName)) {
                                            $image = rand(0,200000). '_' . $imageName;
                                            move_uploaded_file($post_image_temp, 'img\post-thumbnail\\' . $image);

                                            $sec_query = "SELECT * FROM posts ";
                                            $select_user = mysqli_query($connect, $sec_query);

                                            while($row = mysqli_fetch_assoc($select_user)){
                                                $exixting_avater = $row['image'];
                                            }
                                            unlink("img\post-thumbnail/".$exixting_avater);*/

                        move_uploaded_file($post_image_temp, "img/post-thumbnail/$image");
                      


                        // $query = "UPDATE posts SET post_title = '$post_title', post_description = '$post_description', post_thumb='$image' WHERE post_id = '$post_id'";
                        $query = "UPDATE posts SET post_title = '$post_title', post_description = '$post_description',post_author='$post_author', post_thumb='$image',post_category='$post_category', post_tags ='$post_tags ' WHERE post_id = '$post_id'";

                        $update_post_query = mysqli_query($connect, $query);
                        if (!$update_post_query) {
                            die("Query Faield " . mysqli_error($connect));
                        }
                        else{
                            header('Location: all-post.php');
                        }
                    }

                    ?>

                
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
    <!-- Add New Blog Post -->
    

</div>
<!-- End of Main Content -->
<?php include 'includes/footer.php'; ?>
