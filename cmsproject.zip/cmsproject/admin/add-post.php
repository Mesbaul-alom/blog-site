<?php include 'includes/header.php'; ?>

<?php  
        if (isset($_POST['add-post'])) {
            $post_title     = $_POST['post_title'];
            $post_desc      = $_POST['post_desc'];
            $post_author    = $_SESSION['name'];

            $post_image     = $_FILES['image']['name'];
            $post_image_tmp = $_FILES['image']['tmp_name']; 

            $post_category  = $_POST['post_category'];
            $post_tags      = $_POST['post_tags'];


            move_uploaded_file($post_image_tmp, "img/post-thumbnail/$post_image");

            $query = "INSERT INTO posts(post_title, post_description, post_author, post_thumb, post_category, post_tags, post_date) VALUES('$post_title', '$post_desc', '$post_author', '$post_image', '$post_category', '$post_tags', now())";

            $add_new_post = mysqli_query($connect, $query);
            if (!$add_new_post) {
                die("Query Failed" . mysqli_error($connect));
            }
            else{
                header("Location: all-post.php");
            }
        }

    ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">Add Post:</h1>
        <!-- Basic Card Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Add New Post</h6>
            </div>
            <div class="card-body">
                <form action="" method="POST" enctype="multipart/form-data">
                	<div class="form-group">
                		<label>Title</label>
                		<input name="post_title" type="text" class="form-control" autocomplete="off" required="">
                	</div>
                	<div class="form-group">
                		<label>Description</label>
                		<textarea name="post_desc" type="text" class="form-control"></textarea>
                	</div>
                	<!-- <div class="form-group">
                		<label>Author</label>
                		<input name="post_author" type="text" class="form-control" autocomplete="off" required="">
                	</div> -->
                	<div class="form-group">
                		<label>Post Thumbnail</label>
                		<input name="image" type="file" class="form-control-file">
                	</div>
                	<div class="form-group">
                		<label>Category</label>
                		<select name="post_category" class="form-control">
                            <option>Please Select The Post Category</option>
                            <?php  
                                $query = "SELECT * FROM categories" ;
                                $the_cat = mysqli_query($connect, $query);
                                while ($row = mysqli_fetch_assoc($the_cat)) {
                                    $cat_id   = $row['cat_id'];
                                    $cat_name    = $row['cat_name'];

                                ?>
                                <option value="<?php echo $cat_id; ?>"><?php echo $cat_name; ?></option>
                                <?php
                                }

                            ?>
                        </select>
                	</div>
                	<div class="form-group">
                		<label>Tags</label>
                		<input name="post_tags" type="text" class="form-control" autocomplete="off" required="">
                	</div>

                	<div class="form-group">
                		<input name="add-post" type="submit" class="btn btn-primary" value="Publish Post">
                	</div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
    <!-- Add New Blog Post -->
    

</div>
<!-- End of Main Content -->
<?php include 'includes/footer.php'; ?>
