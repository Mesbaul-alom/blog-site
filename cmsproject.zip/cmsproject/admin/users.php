<?php include 'includes/header.php'; ?>
<!-- Begin Page Content -->
<div class="container-fluid">
	<!-- Page Heading -->
	<div class="card shadow mb-4">
		<div class="card-header py-3">
			<h6 class="m-0 font-weight-bold text-primary">Basic Card Example</h6>
		</div>
		<div class="card-body">
			<h1 class="h3 mb-4 text-gray-800">Users Details</h1>
			<?php
				$do = isset($_GET['do'])? $_GET['do'] : 'Manage';
				if($do == "Manage"){
			?>
			<table class="table">
				<thead class="thead-dark">
					<tr>
						<th scope="col">Sl.</th>
						<th scope="col">Avater</th>
						<th scope="col">Full Name</th>
						<th scope="col">Username</th>
						<th scope="col">Email</th>
						<th scope="col">Phone</th>
						<th scope="col">Role</th>
						<th scope="col">Active Status</th>
						<th scope="col">Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$query = "SELECT * FROM users";
						$all_user = mysqli_query($connect, $query);
						$sl = 0;
						while ($row = mysqli_fetch_assoc($all_user)) {
							$id 		= $row['id'];
							$name 		= $row['name'];
							$username 	= $row['username'];
							$password 	= $row['password'];
							$email 		= $row['email'];
							$phone 		= $row['phone'];
							$address 	= $row['address'];
							$avater 	= $row['avater'];
							$role 		= $row['role'];
							$is_active 	= $row['is_active'];
							$join_date 	= $row['join_date'];
							$sl++;
					?>
					<tr>
						<th scope="row"><?php echo $sl; ?></th>
						<td>

							

							<?php  
								if (!empty($avater)) {
									?>
									<img src="img/user-avater/<?php echo $avater; ?>" style="width: 35px; border-radius: 50%;">
									<?php
								}
								else{
									?>
									<img src="img/user-avater/default.jpg" style="width: 35px; border-radius: 50%;">
									<?php
								}
							?>
							
						</td>
						<td><?php echo $name; ?></td>
						<td><?php echo $username; ?></td>
						<td><?php echo $email; ?></td>
						<td><?php echo $phone; ?></td>
						<td> 
							<?php  
								if ($role==0) {
									echo '<span class="badge badge-success">Administrator</span>';
								}
								elseif ($role == 1){
									echo '<span class="badge badge-primary">Editor</span>';
								}
								else{
									echo '<span class="badge badge-danger">Suspended</span>';
								}
							?>
						</td>

						<td> 
							<?php  
								if ($is_active==0) {
									echo '<span class="badge badge-danger">Inactive</span>';
								}
								elseif ($is_active == 1){
									echo '<span class="badge badge-success">Active</span>';
								}
								else{
									echo '<span class="badge badge-danger">Suspended</span>';
								}
							?>
						</td>
						<td>
							<div class="btn-group">
								<a class="text-success" href="#"><i class="fa fa-eye" data-toggle="modal" data-target="#userProfile<?php echo $id; ?>"></i></a>

								<a class="text-primary ml-2 mr-2" href="users.php?do=Edit&update=<?php echo $id; ?>"><i class="fa fa-pen"></i></a>

								<a class="text-danger" href="#"><i class="fa fa-trash" data-toggle="modal" data-target="#exampleModal<?php echo $id; ?>"></i></a>
							</div>

							<!-- View User Profile -->
							<div class="modal fade" id="userProfile<?php echo $id; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
							  <div class="modal-dialog">
							    <div class="modal-content">
							      <div class="row">
							      	<div class="col-md-12">
							      		<div class="d-flex justify-content-center pt-4 pb-4">
							      			<img src="img/user-avater/<?php echo $avater; ?>" style="width: 100px; height: 100px; border: 2px solid #333; border-radius: 50%;">
							      		</div>
							      	</div>
							      	<div class="col-md-12">
							      		<table class="table table-striped table-dark">
										  <tbody>
										    <tr>
										      <td>Fullname: </td>
										      <td><?php echo $name; ?></td>
										    </tr>
										    <tr>
										      <td>Username: </td>
										      <td><?php echo $username; ?></td>
										    </tr>
										    <tr>
										      <td>Email Address: </td>
										      <td><?php echo $email; ?></td>
										    </tr>
										    <tr>
										      <td>Phone Number: </td>
										      <td><?php echo $phone; ?></td>
										    </tr>
										    <tr>
										      <td>Address: </td>
										      <td><?php echo $address; ?></td>
										    </tr>
										    <tr>
										      <td>User Role: </td>
										      <td>
										      	<?php  
													if ($role==0) {
														echo '<p>Administrator</p>';
													}
													elseif ($role == 1){
														echo '<p>Editor</p>';
													}
													else{
														echo '<p>Suspended</p>';
													}
												?>

										      </td>
										    </tr>
										    <tr>
										      <td>Join Date: </td>
										      <td><?php echo $join_date; ?></td>
										    </tr>
										  </tbody>
										</table>
							      	</div>
							      </div>
							    </div>
							  </div>
							</div>
							<!-- Delete User Modal -->
							<div class="modal fade" id="exampleModal<?php echo $id; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
							  <div class="modal-dialog">
							    <div class="modal-content">
							      <div class="modal-header">
							        <h5 class="modal-title" id="exampleModalLabel">Do you want to delete this item?</h5>
							        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
							          <span aria-hidden="true">&times;</span>
							        </button>
							      </div>
							      <div class="modal-body text-center">
							        <a class="btn btn-danger" href="users.php?do=Delete&delete=<?php echo $id; ?>">Yes</a>
							        <a class="btn btn-primary" data-dismiss="modal" href="#">No</a>
							      </div>
							    </div>
							  </div>
							</div>
						</td>
					</tr>
					<?php
						}
					?>
					
				</tbody>
			</table>
		</div></div>
		<?php
		}
		else if($do == "Add"){
		?>
		<form action="?do=Insert" method="POST" enctype="multipart/form-data">
			<div class="row">
				<div class="col-md-6">
					<div class="card shadow mb-4">
						<div class="card-header py-3">
							<h6 class="m-0 font-weight-bold text-primary">Add User Information</h6>
						</div>
						<div class="card-body">
							<div class="form-group">
								<input name="name" type="text" class="form-control" required="" placeholder="Full Name" autocomplete="off">
							</div>
							<div class="form-group">
								<input name="username" type="text" class="form-control" required="" placeholder="User Name" autocomplete="off">
							</div>
							<div class="form-group">
								<input name="password" type="password" class="form-control" required="" placeholder="Password" autocomplete="off">
							</div>
							<div class="form-group">
								<input name="re-password" type="password" class="form-control" required="" placeholder="Re Password" autocomplete="off">
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<input name="email" type="email" class="form-control" required="" placeholder="Email Address" autocomplete="off">
					</div>
					<div class="form-group">
						<input name="phone" type="text" class="form-control" required="" placeholder="Phone Number" autocomplete="off">
					</div>
					<div class="form-group">
						<input name="address" type="text" class="form-control" required="" placeholder="Address" autocomplete="off">
					</div>
					<div class="form-group">
						<select name="role" class="form-control">
							<option value="3">Select Role</option>
							<option value="0">Administrator</option>
							<option value="1">Editor</option>
						</select>
					</div>
					<div class="form-group">
						<label for="avater">User Avater</label>
						<input name="avater" type="file" class="form-control-file">
					</div>
					<div class="form-group">
						<input name="submit" type="submit" class="btn btn-primary">
					</div>
				</div>
			</div>
		</form>
		<?php
		}
		else if($do == "Insert"){
			if ($_SERVER['REQUEST_METHOD'] == 'POST') {
				$name 			= $_POST['name'];
				$username 		= $_POST['username'];
				$password 		= $_POST['password'];
				$re_password 	= $_POST['re-password'];
				$email 			= $_POST['email'];
				$phone 			= $_POST['phone'];
				$address 		= $_POST['address'];
				$role 			= $_POST['role'];

				$avater 	= $_FILES['avater'];
				$avaterName = $_FILES['avater']['name'];
				$avaterSize = $_FILES['avater']['size'];
				$avaterType = $_FILES['avater']['type'];
				$avaterTmp 	= $_FILES['avater']['tmp_name'];

				$avaterAllowedExtension = array('jpg', 'jpeg', 'png');
				$avaterExtension = strtolower(end(explode('.', $avaterName)));

				$formError = array();
				if (strlen($username) < 4) {
					$formError = 'Username is to small';
				}
				if($password != $re_password){
					$formError = 'Password doesn\'t match';
				}
				if (!empty($avaterName) && !in_array($avaterExtension, $avaterAllowedExtension)) {
					$formError = "Please upload valid image";
				}
				
				foreach ($formError as $error) {
					echo '<div class="alert alert-danger">'. $error .'</div>';
				}

				if (empty($formError)) {
					$avater = rand(0,200000). '_' . $avaterName;
					move_uploaded_file($avaterTmp, 'img\user-avater\\' . $avater);

					$hassedPass = sha1($password);

					$query = "INSERT INTO users (name, username, password, email, phone, address, avater, role, join_date) VALUES ('$name', '$username', '$hassedPass', '$email', '$phone', '$address', '$avater', '$role', now())";

					$add_user = mysqli_query($connect, $query);
					if (!$add_user) {
						die("Query Falid" . mysqli_error($connect));
					}
					else{
						header("Location: users.php?do=Manage");
					}

				}
			}
		}
		// Edit User Info
		else if($do == "Edit"){
			if (isset($_GET['update'])) {
				$the_user = $_GET['update'];


				$query = "SELECT * FROM users WHERE id = '$the_user'";
				$update_user = mysqli_query($connect, $query);

				while($row = mysqli_fetch_assoc($update_user)){
					$user_id 	= $row['id'];
					$name 		= $row['name'];
					$username 	= $row['username'];
					$password 	= $row['password'];
					$email 		= $row['email'];
					$phone 		= $row['phone'];
					$address 	= $row['address'];
					$avater 	= $row['avater'];
					$role 		= $row['role'];
					$is_active 	= $row['is_active'];
					$join_date 	= $row['join_date'];

				?>
					<form action="?do=Update" method="POST" enctype="multipart/form-data">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<input name="name" type="text" class="form-control" required="" placeholder="Full Name" autocomplete="off" value="<?php echo $name; ?>">
								</div>
								<div class="form-group">
									<input name="username" type="text" class="form-control" required="" placeholder="User Name" autocomplete="off" value="<?php echo $username; ?>">
								</div>
								<div class="form-group">
									<input name="email" type="email" class="form-control" required="" placeholder="Email Address" autocomplete="off" value="<?php echo $email; ?>">
								</div>
								<div class="form-group">
									<input name="phone" type="text" class="form-control" required="" placeholder="Phone Number" autocomplete="off" value="<?php echo $phone; ?>">
								</div>
							</div>
							<div class="col-md-6">
								
								<div class="form-group">
									<input name="address" type="text" class="form-control" required="" placeholder="Address" autocomplete="off" value="<?php echo $address; ?>">
								</div>
								<div class="form-group">
									<select name="role" class="form-control">
										<option value="3">Select Role</option>
										<option value="0" <?php if($role == 0){ echo 'selected'; } ?>>Administrator</option>
										<option value="1" <?php if($role == 1){ echo 'selected'; } ?>>Editor</option>
									</select>
								</div>
								<div class="form-group">
									<select name="is_active" class="form-control">
										<option value="3">Active Status</option>
										<option value="0" <?php if($is_active == 0){ echo 'selected'; } ?>>Inactive</option>
										<option value="1" <?php if($is_active == 1){ echo 'selected'; } ?>>Active</option>
									</select>
								</div>
								<div class="form-group">
									<label for="avater">User Avater</label>
									<br>
									<img src="img/user-avater/<?php echo $avater; ?>" height="40px">
									<br>
									<input name="avater" type="file" class="form-control-file">
								</div>
								<div class="form-group">
									<input type="hidden" name="update_user_id" value="<?php echo $user_id; ?>">
									<input name="submit" type="submit" class="btn btn-primary" value="Save Change">
								</div>
							</div>
						</div>
					</form>

				<?php
				}

			}
		}
		else if($do == "Update"){ ?>
			<div class="row">
				<div class="col-md-6">
					<div class="card shadow mb-4">
						<div class="card-header py-3">
							<h6 class="m-0 font-weight-bold text-primary">Update User Information</h6>
						</div>
						<div class="card-body">
							<?php  
								if ($_SERVER['REQUEST_METHOD'] == 'POST') {
									$update_user_id = $_POST['update_user_id'];

									$name 			= $_POST['name'];
									$username 		= $_POST['username'];
									// $password 		= $_POST['password'];
									// $re_password 	= $_POST['re-password'];
									$email 			= $_POST['email'];
									$phone 			= $_POST['phone'];
									$address 		= $_POST['address'];
									$role 			= $_POST['role'];
									$is_active 		= $_POST['is_active'];

									$avater 	= $_FILES['avater'];
									$avaterName = $_FILES['avater']['name'];
									$avaterSize = $_FILES['avater']['size'];
									$avaterType = $_FILES['avater']['type'];
									$avaterTmp 	= $_FILES['avater']['tmp_name'];

									$avaterAllowedExtension = array('jpg', 'jpeg', 'png');
									$avaterExtension = strtolower(end(explode('.', $avaterName)));

									$formError = array();
									if (strlen($username) < 4) {
										$formError = 'Username is to small';
									}
									if($password != $re_password){
										$formError = 'Password doesn\'t match';
									}
									if (!empty($avaterName) && !in_array($avaterExtension, $avaterAllowedExtension)) {
										$formError = "Please upload valid image";
									}
									
									foreach ($formError as $error) {
										echo '<div class="alert alert-danger">'. $error .'</div>';
									}

									if (empty($formError)) {
										if (!empty($avaterName)) {
											$avater = rand(0,200000). '_' . $avaterName;
											move_uploaded_file($avaterTmp, 'img\user-avater\\' . $avater);

											$sec_query = "SELECT * FROM users WHERE id='$update_user_id'";
											$select_user = mysqli_query($connect, $sec_query);

											while($row = mysqli_fetch_assoc($select_user)){
												$exixting_avater = $row['avater'];
											}
											unlink("img\user-avater/".$exixting_avater);

											$query = "UPDATE users SET name='$name', username='$username', email='$email', phone='$phone', address='$address', avater='$avater', role='$role', is_active='$is_active' WHERE id='$update_user_id'";

											$update_user = mysqli_query($connect, $query);
											if (!$update_user) {
												die("Query Falid" . mysqli_error($connect));
											}
											else{
												header("Location: users.php?do=Manage");
											}
										}
										else{
											$query = "UPDATE users SET name='$name', username='$username', email='$email', phone='$phone', address='$address', role='$role', is_active='$is_active' WHERE id='$update_user_id'";

											$update_user = mysqli_query($connect, $query);
											if (!$update_user) {
												die("Query Falid" . mysqli_error($connect));
											}
											else{
												header("Location: users.php?do=Manage");
											}
										}

										

									}
								}

							?>
						</div>
					</div>
				</div>
			</div>
		<?php }
		else if($do == "Delete"){
			if (isset($_GET['delete'])) {
				$the_delete_id = $_GET['delete'];
				// $query = "SELECT * FROM users WHERE id ='$the_delete_id'";

				// $select_user = mysqli_query($connect, $query);

				// while($row = mysqli_fetch_assoc($select_user)){
				// 	$
				// }

				$delete_query = "DELETE FROM users WHERE id = '$the_delete_id'";
				$delete_done  = mysqli_query($connect, $delete_query);

				if (!$delete_done ) {
					die("Query Faild" . mysqli_error($connect));
				}
				else{
					header("Location: users.php?do=Manage");
				}
			}
		}
		?>
	</div>
	<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->
<?php include 'includes/footer.php'; ?>