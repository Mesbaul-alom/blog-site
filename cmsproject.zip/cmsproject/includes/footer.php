  <!-- Contact Area Start -->
    <section id="contact" class="contact-area section-padding">
        <div class="container">
            <div class="row">

                <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                    <div class="contact-abt">
                        <h4>About Us</h4>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora dolorum dolore cupiditate alias? Cum officiaTempora dolorum dolore empora dolorum dolore cupiditate alias? Cum officiaTempora dolorum dolore cupiditate alias? Cum officia voluptatum voluptate nobis. Non, beatae.</p>
                        <div class="contact-social d-flex">
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-pinterest-p"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-3 col-12">
                    <div class="quick-links">
                        <h4>Quick Links</h4>
                        <a href="#">About</a>
                        <a href="#">Prevention</a>
                        <a href="#">Symptom</a>
                        <a href="#">FAQ</a>
                        <a href="#">Blogs</a>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-3 col-12">
                    <div class="useful-links">
                        <h4>Useful Links</h4>
                        <a href="#">WHO</a>
                        <a href="#">IEDCR</a>
                        <a href="#">NHS</a>
                        <a href="#">Health</a>
                        <a href="#">Care</a>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- Contact Area Ends -->
 <!-- Footer Area Start -->
    <footer class="footer-area text-center">
        <p class="wow fadeInUp">Copyright &copy; 2020 | Made with &hearts; by DevsCart.</p>
    </footer>
    <!-- Footer Area Ends -->

    <!-- Scroll to top Area Start -->
    <div class="scroll-top hide">
        <a href="#">
            <i class="fas fa-chevron-up"></i>
        </a>
    </div>
    <!-- Scroll to top Area Ends -->

    <!-- Jquery JS -->
    <script src="assets/js/jquery-1.12.4.min.js"></script>
    <!-- Popper Js -->
    <script src="assets/js/popper.min.js"></script>
    <!-- Bootstrap 4 JS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- FontAwesome Js -->
    <script src="assets/js/fa-all.min.js"></script>
    <!-- Wow Js -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Slick Slider -->
    <script src="assets/js/slick.min.js"></script>
    <!-- Slick Animation -->
    <script src="assets/js/slick-animation.js"></script>
    <!-- Waypoints JS -->
    <script src="assets/js/waypoints.min.js"></script>
    <!-- Counter Up -->
    <script src="assets/js/jquery.counterup.min.js"></script>
    <!-- Custom js -->
    <script src="assets/js/custom.js"></script>

</body>

</html>
