<?php 
    include "db.php";
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>KODIV | COVID-19 Medical Awareness Template</title>
    <meta name="description" content="COVID-19">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- FavIcon -->
    <link rel="icon" href="assets/images/favicon.png">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="assets/css/fa-all.min.css">
    <!-- Animate -->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!-- Slick Slider -->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!-- Style css -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/blog-details.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" href="assets/css/blog-responsive.css">
</head>

<body>
    <!-- PreLoader -->
    <!-- <div id="loader"></div> -->
    <!-- PreLoader -->

    <!-- Header Area Start -->
    <header class="header-area">

        <!-- NavBar Start -->
        <div id="main-menu" class="main-menu">
            <div class="container">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="navbar-brand" href="index.php">
                        <img src="assets/images/logo.png" alt="" class="img-fluid">
                    </a>
                    <!--LOGO -->
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <!-- Menu -->
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ml-auto text-uppercase">
                            <?php  
                                $sql = "SELECT * FROM categories ORDER BY cat_name ASC";
                                $nav_item = mysqli_query($connect, $sql);

                                while ($row = mysqli_fetch_assoc($nav_item)) {
                                    $cat_id = $row['cat_id'];
                                    $cat_name = $row['cat_name'];
                            ?>
                             <li class="nav-item active">
                                <a class="nav-link" href="category.php?id=<?php echo $cat_id; ?>"><?php echo $cat_name; ?><span class="sr-only">(current)</span></a>
                            </li>
                            <?php
                                }
                            ?>

                           
                            
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!-- NavBar Ends -->