<div class="sidebar">
                        <!-- Search -->
                        <div class="search sidebar-bor-bot">
                            <input type="text" name="search" placeholder="Search Here">
                            <a href="#"><i class="fas fa-search"></i></a>
                        </div>
                         <div class="categories sidebar-bor-bot">
                        <h3>Categories</h3>
                        <ul class="list-inline">
  <?php  
                                $sql = "SELECT * FROM categories";
                                $cat_items = mysqli_query($connect, $sql);

                                while ($row = mysqli_fetch_assoc($cat_items)) {
                                    $cat_id = $row['cat_id'];
                                    $cat_name = $row['cat_name'];
                                    $query="SELECT *FROM posts WHERE post_category='$cat_id'";
                                    $all_cat=mysqli_query($connect,$query);
                                    $total_cat_num=mysqli_num_rows($all_cat);
                            ?>
                            
                             <li class="mr-1"><a class="text-info" href="category.php?id=<?php echo $cat_id; ?>"><?php echo $cat_name; ?>[<?php echo $total_cat_num;?>]</a></li>
                        
                           
                            <?php
                                }
                            ?>
                        <!-- Categories -->
                       </ul>
</div>
                        <!-- Insta -->
                        <div class="insta sidebar-bor-bot">
                            <h3>Instagram</h3>
                            <div class="row">
                                <div class="col-lg-4 col-6">
                                    <a href="#">
                                        <img src="assets/images/blog1.jpg" alt="" class="img-fluid">
                                    </a>
                                </div>
                                <div class="col-lg-4 col-6">
                                    <a href="#">
                                        <img src="assets/images/blog2.jpg" alt="" class="img-fluid">
                                    </a>
                                </div>
                                <div class="col-lg-4 col-6">
                                    <a href="#">
                                        <img src="assets/images/blog3.jpg" alt="" class="img-fluid">
                                    </a>
                                </div>
                                <div class="col-lg-4 col-6">
                                    <a href="#">
                                        <img src="assets/images/blog2.jpg" alt="" class="img-fluid">
                                    </a>
                                </div>
                                <div class="col-lg-4 col-6">
                                    <a href="#">
                                        <img src="assets/images/blog3.jpg" alt="" class="img-fluid">
                                    </a>
                                </div>
                                <div class="col-lg-4 col-6">
                                    <a href="#">
                                        <img src="assets/images/blog1.jpg" alt="" class="img-fluid">
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Follow Us -->
                        <div class="follow-us">
                            <h3>Follow Us</h3>
                            <div class="sidebar-social d-flex">
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-twitter"></i></a>
                                <a href="#"><i class="fab fa-pinterest-p"></i></a>
                                <a href="#"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>

                    </div>