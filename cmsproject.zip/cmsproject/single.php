<?php include 'includes/header.php'; ?>
        <!-- BreadCrumb Start -->
        <div class="breadcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-inner">
                            <h2>Blog Details</h2>
                            <p>
                                <a href="index.php">Home</a>
                                <span>Blog Details</span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- BreadCrumb Ends -->
 
    <!-- Header Area Ends -->

    <!-- Blog Details Wrapper Start -->
    <div class="blog-details-wrapper section-padding">
        <div class="container">
            <div class="row">
                <!-- Blog Details -->
                <div class="col-lg-8 col-md-8 col-12">
                    <div class="blog-details">
                          <?php  
                        if (isset($_GET['id'])) {
                           $the_post_id = $_GET['id'];
                           $sql="SELECT * FROM posts WHERE post_id='$the_post_id'";
                           $read_post=mysqli_query($connect,$sql);

                        while($row = mysqli_fetch_assoc($read_post)){
                            $post_id            = $row['post_id'];
                            $post_title         = $row['post_title'];
                            $post_description   = $row['post_description'];
                            $post_author        = $row['post_author'];
                            $post_thumb         = $row['post_thumb'];
                            $post_category      = $row['post_category'];
                            $post_tags          = $row['post_tags'];
                            $post_date          = $row['post_date'];
                    
                        
                    ?>
                     <div class="blog-item">
                        <div class="blog-img">
                            <!-- Blog Image -->
                            <img src="admin/img/post-thumbnail/<?php echo $post_thumb; ?>" alt="Blog" class="img-fluid">
                          
                        </div>
                        <div class="blog-info">
                            <p class="date">
                                <i class="far fa-calendar-alt"></i>
                                <?php echo "$post_date"; ?>
                            </p>
                            <p class="author">
                                <i class="fas fa-user-tie"></i>
                                <?php echo "$post_author"; ?>
                            </p>
                            <p class="info-cmnt">
                                <i class="far fa-comments"></i>
                                101
                            </p>
                        </div>
                        <div class="blog-content">
                            <h2><?php echo "$post_title"; ?></h2>
                            <p>
                                <?php echo "$post_description"; ?>
                            </p>
                            
                            
                          
                            </div>
                <?php }} ?>
                       
                            <div class="blog-cmnt">
                                <h3>Comments</h3>
                                <!-- Single Comment -->
                                <div class="single-cmnt">
                                    <div class="comment">
                                        <div class="row">
                                            <div class="col-lg-3 col-md-3 col-sm-3 col-12">
                                                <div class="comment-img">
                                                    <img src="assets/images/comment.jpg" alt="" class="img-fluid">
                                                </div>
                                            </div>
                                            <div class="col-lg-9 col-md-9 col-sm-9 col-12">
                                                <div class="single-cmnt-inner">
                                                    <div>
                                                        <h4 class="comment-name">Dale Steyn</h4>
                                                        <a class="comment-reply-btn" href="#">Reply</a>
                                                    </div>
                                                    <p class="comment-time">1 Day Ago</p>
                                                    <p class="comment-msg">
                                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, quae suscipit deleniti eligendi dolores ipsam perferendis quidem sequi voluptatem sed.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="comment-reply">
                                        <div class="row">
                                            <div class="col-lg-9 col-md-9 col-sm-9 col-12">
                                                <div class="comment-reply-inner">
                                                    <div>
                                                        <h4 class="comment-name">Brett Lee</h4>
                                                        <a class="comment-reply-btn" href="#">Reply</a>
                                                    </div>
                                                    <p class="comment-time">1 Day Ago</p>
                                                    <p class="comment-msg">
                                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, quae suscipit deleniti
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="col-lg-3 col-md-3 col-sm-3 col-12">
                                                <div class="comment-img">
                                                    <img src="assets/images/comment1.jpg" alt="" class="img-fluid">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Single Comment -->
                                <div class="single-cmnt">
                                    <div class="comment">
                                        <div class="row">
                                            <div class="col-lg-3 col-md-3 col-sm-3 col-12">
                                                <div class="comment-img">
                                                    <img src="assets/images/comment.jpg" alt="" class="img-fluid">
                                                </div>
                                            </div>
                                            <div class="col-lg-9 col-md-9 col-sm-9 col-12">
                                                <div class="single-cmnt-inner">
                                                    <div>
                                                        <h4 class="comment-name">Dale Steyn</h4>
                                                        <a class="comment-reply-btn" href="#">Reply</a>
                                                    </div>
                                                    <p class="comment-time">1 Day Ago</p>
                                                    <p class="comment-msg">
                                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, quae suscipit deleniti eligendi dolores ipsam perferendis quidem sequi voluptatem sed.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="comment-reply">
                                        <div class="row">
                                            <div class="col-lg-9 col-md-9 col-sm-9 col-12">
                                                <div class="comment-reply-inner">
                                                    <div>
                                                        <h4 class="comment-name">Brett Lee</h4>
                                                        <a class="comment-reply-btn" href="#">Reply</a>
                                                    </div>
                                                    <p class="comment-time">1 Day Ago</p>
                                                    <p class="comment-msg">
                                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, quae suscipit deleniti
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="col-lg-3 col-md-3 col-sm-3 col-12">
                                                <div class="comment-img">
                                                    <img src="assets/images/comment1.jpg" alt="" class="img-fluid">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <!-- Comment Box -->
                            <div class="cmnt-box">
                                <h3>Leave a Comment</h3>
                                <div class="cmnt-form">
                                    <form>
                                        <input type="text" name="u_name" placeholder="Your Name*" required>
                                        <input type="email" name="u_email" placeholder="Your Email*" required>
                                        <textarea name="u_cmnt" placeholder="Your Message*" required></textarea>
                                        <input class="cmnt-form-btn" type="submit">
                                    </form>
                                </div>
                            </div>
                            <!-- Comment Box -->

                        </div>
                    </div>
                </div>
                <!-- Blog Details -->

                <!-- SideBar -->
                <div class="col-lg-4 col-md-4 col-12">
                    
                </div>
                <!-- SideBar -->
            </div>
        </div>
    </div>
    <!-- Blog Details Wrapper Ends -->

<?php include 'includes/footer.php'; ?>